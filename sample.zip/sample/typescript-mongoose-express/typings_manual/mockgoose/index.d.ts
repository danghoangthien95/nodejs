declare module "mockgoose" {
    function mockgoose(db: any): any;
    export = mockgoose;
}
