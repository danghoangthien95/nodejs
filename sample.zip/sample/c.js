function queryUser(userId, callback) {
	setTimeout(() => {
		callback(null, {
			id: userId,
			name: 'user_' + userId
		})
	}, 100)
}

function currentUser(callback) {
	setTimeout(() => {
		callback(null, {
			userId: '123'
		})
	})
}

function queryArticles(userId, callback) {
	setTimeout(() => {
		// throw "ABC";
		callback("not ok!", [{
			id: '1',
			title: 'article_1'
		}, {
			id: '2',
			title: 'article_2'
		}])
	}, 100)
}

function main() {
	currentUser(function(err, cuser) {
		if (err) {
			return;
		}
		queryArticles(cuser, (err, articles) => {
			if (err) return;
			console.log('ARTICLES', articles);
		})
	}) 
}

function promisify(fn, ...args) {
	return new Promise((resolve, reject) => {
		fn(...args, (err, res) => {
			if (err) reject(err);
			else resolve(res);
		})
	})
}


function main2() {
	promisify(currentUser).then((cuser) => {
		console.log('current user', cuser);
		return cuser.userId;

	}).then((userId) => {
		// throw "Something not okay!";
		return promisify(queryArticles, userId);

	}).then((articles) => {
		console.log('Articles', articles);
	}).then(null, (error) => {
		console.log('CATCH ERROR', error);
	})
}

async function main3() {
 // try {
	var cuser = await promisify(currentUser);
	var articles = await promisify(queryArticles, cuser.userId);
	console.log('Articles', articles);
	return 'It\'s ok!'
  //} catch(err) {
  //  console.log("CATCH", err);
  //}
}

main3().then((res) => {
	console.log('OK', res);
}, (err) => {
	console.log('ERROR', err);
});