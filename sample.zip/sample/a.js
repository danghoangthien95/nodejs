function sum(a, b) {
	return a + b;
}

function wait() {
	setTimeout(() => {
		try {
			somethingBad();
		} catch(e) {
			console.log('CATCH!')
		}
	}, 1000)
}
console.log(sum(1,2))

function somethingBad() {
	throw new Error("Oops!")
}

try {
    // somethingBad();
    wait();
} catch(e) {
	console.log("Catch error");
}
console.log('done!')